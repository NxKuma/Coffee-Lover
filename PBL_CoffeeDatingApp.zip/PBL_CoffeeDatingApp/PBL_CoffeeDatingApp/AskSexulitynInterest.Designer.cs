﻿
namespace PBL_CoffeeDatingApp
{
    partial class AskSexulitynInterest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AskSexulitynInterest));
            this.roundPanel1 = new PBL_CoffeeDatingApp.RoundPanel();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.custRadioButt3 = new PBL_CoffeeDatingApp.CustRadioButt();
            this.custRadioButt2 = new PBL_CoffeeDatingApp.CustRadioButt();
            this.custRadioButt1 = new PBL_CoffeeDatingApp.CustRadioButt();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.custButton1 = new PBL_CoffeeDatingApp.CustButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.roundPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // roundPanel1
            // 
            this.roundPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.roundPanel1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.roundPanel1.BorderColor = System.Drawing.Color.Transparent;
            this.roundPanel1.BorderRadius = 40;
            this.roundPanel1.BorderSize = 0;
            this.roundPanel1.Controls.Add(this.label9);
            this.roundPanel1.Controls.Add(this.label8);
            this.roundPanel1.Controls.Add(this.label7);
            this.roundPanel1.Controls.Add(this.label5);
            this.roundPanel1.Controls.Add(this.label1);
            this.roundPanel1.Controls.Add(this.custRadioButt3);
            this.roundPanel1.Controls.Add(this.custRadioButt2);
            this.roundPanel1.Controls.Add(this.custRadioButt1);
            this.roundPanel1.Controls.Add(this.label6);
            this.roundPanel1.Controls.Add(this.textBox6);
            this.roundPanel1.Controls.Add(this.textBox5);
            this.roundPanel1.Controls.Add(this.label4);
            this.roundPanel1.Controls.Add(this.label3);
            this.roundPanel1.Controls.Add(this.label2);
            this.roundPanel1.Controls.Add(this.pictureBox1);
            this.roundPanel1.ForeColor = System.Drawing.Color.Transparent;
            this.roundPanel1.Location = new System.Drawing.Point(39, 195);
            this.roundPanel1.Name = "roundPanel1";
            this.roundPanel1.Size = new System.Drawing.Size(540, 627);
            this.roundPanel1.TabIndex = 5;
            this.roundPanel1.TextColor = System.Drawing.Color.Transparent;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.label9.Location = new System.Drawing.Point(145, 571);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(386, 28);
            this.label9.TabIndex = 27;
            this.label9.Text = "gender idenitty, and sexual orientation.";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.label8.Location = new System.Drawing.Point(171, 534);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(365, 28);
            this.label8.TabIndex = 26;
            this.label8.Text = "their race, beliefs, ethnicity, size, sex,";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.label7.Location = new System.Drawing.Point(189, 497);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(341, 28);
            this.label7.TabIndex = 25;
            this.label7.Text = " with kindness n respect no matter";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.label5.Location = new System.Drawing.Point(193, 459);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(331, 28);
            this.label5.TabIndex = 24;
            this.label5.Text = "Here in coffee, we treat everyone";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.label1.Location = new System.Drawing.Point(81, 398);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(380, 38);
            this.label1.TabIndex = 22;
            this.label1.Text = "AND SHARE A LATTE LOVE!";
            // 
            // custRadioButt3
            // 
            this.custRadioButt3.AutoSize = true;
            this.custRadioButt3.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custRadioButt3.Font = new System.Drawing.Font("Nirmala UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.custRadioButt3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custRadioButt3.Location = new System.Drawing.Point(88, 303);
            this.custRadioButt3.MinimumSize = new System.Drawing.Size(0, 21);
            this.custRadioButt3.Name = "custRadioButt3";
            this.custRadioButt3.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.custRadioButt3.Size = new System.Drawing.Size(206, 29);
            this.custRadioButt3.TabIndex = 21;
            this.custRadioButt3.TabStop = true;
            this.custRadioButt3.Text = "Interested in BOTH";
            this.custRadioButt3.UnCheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custRadioButt3.UseVisualStyleBackColor = true;
            // 
            // custRadioButt2
            // 
            this.custRadioButt2.AutoSize = true;
            this.custRadioButt2.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custRadioButt2.Font = new System.Drawing.Font("Nirmala UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.custRadioButt2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custRadioButt2.Location = new System.Drawing.Point(88, 257);
            this.custRadioButt2.MinimumSize = new System.Drawing.Size(0, 21);
            this.custRadioButt2.Name = "custRadioButt2";
            this.custRadioButt2.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.custRadioButt2.Size = new System.Drawing.Size(315, 29);
            this.custRadioButt2.TabIndex = 20;
            this.custRadioButt2.TabStop = true;
            this.custRadioButt2.Text = "Interested in looking for Female";
            this.custRadioButt2.UnCheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custRadioButt2.UseVisualStyleBackColor = true;
            // 
            // custRadioButt1
            // 
            this.custRadioButt1.AutoSize = true;
            this.custRadioButt1.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custRadioButt1.Font = new System.Drawing.Font("Nirmala UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.custRadioButt1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custRadioButt1.Location = new System.Drawing.Point(88, 212);
            this.custRadioButt1.MinimumSize = new System.Drawing.Size(0, 21);
            this.custRadioButt1.Name = "custRadioButt1";
            this.custRadioButt1.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.custRadioButt1.Size = new System.Drawing.Size(297, 29);
            this.custRadioButt1.TabIndex = 19;
            this.custRadioButt1.TabStop = true;
            this.custRadioButt1.Text = "Interested in looking for Male";
            this.custRadioButt1.UnCheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custRadioButt1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.label6.Location = new System.Drawing.Point(318, 57);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 28);
            this.label6.TabIndex = 17;
            this.label6.Text = "Pronouns";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(44)))), ((int)(((byte)(58)))));
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Font = new System.Drawing.Font("MS UI Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.textBox6.Location = new System.Drawing.Point(318, 97);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(156, 47);
            this.textBox6.TabIndex = 15;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(44)))), ((int)(((byte)(58)))));
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Font = new System.Drawing.Font("MS UI Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.textBox5.Location = new System.Drawing.Point(64, 97);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(222, 47);
            this.textBox5.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.label4.Location = new System.Drawing.Point(62, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 28);
            this.label4.TabIndex = 13;
            this.label4.Text = "Sexuality";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.label3.Location = new System.Drawing.Point(64, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(249, 28);
            this.label3.TabIndex = 12;
            this.label3.Text = "Interested in looking for:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Nirmala UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.label2.Location = new System.Drawing.Point(41, 357);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(470, 38);
            this.label2.TabIndex = 6;
            this.label2.Text = "STAY GROUNDED, GIVE WARMTH ";
            // 
            // custButton1
            // 
            this.custButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custButton1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custButton1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.custButton1.BorderRadius = 50;
            this.custButton1.BorderSize = 5;
            this.custButton1.FlatAppearance.BorderSize = 0;
            this.custButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.custButton1.Font = new System.Drawing.Font("Nirmala UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.custButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.custButton1.Location = new System.Drawing.Point(182, 871);
            this.custButton1.Name = "custButton1";
            this.custButton1.Size = new System.Drawing.Size(264, 55);
            this.custButton1.TabIndex = 2;
            this.custButton1.Text = "Brew Matches";
            this.custButton1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.custButton1.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(-16, 350);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(240, 302);
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // AskSexulitynInterest
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(620, 977);
            this.Controls.Add(this.roundPanel1);
            this.Controls.Add(this.custButton1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AskSexulitynInterest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AskSexulitynInterest";
            this.roundPanel1.ResumeLayout(false);
            this.roundPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private RoundPanel roundPanel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private CustButton custButton1;
        private System.Windows.Forms.Label label2;
        private CustRadioButt custRadioButt1;
        private CustRadioButt custRadioButt3;
        private CustRadioButt custRadioButt2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}