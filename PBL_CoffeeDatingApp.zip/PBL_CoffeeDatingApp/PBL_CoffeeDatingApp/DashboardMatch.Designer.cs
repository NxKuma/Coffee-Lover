﻿
namespace PBL_CoffeeDatingApp
{
    partial class DashboardMatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardMatch));
            this.roundPanel1 = new PBL_CoffeeDatingApp.RoundPanel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.roundPanel2 = new PBL_CoffeeDatingApp.RoundPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ProfileButt = new System.Windows.Forms.PictureBox();
            this.MatchButt = new System.Windows.Forms.PictureBox();
            this.DontMatchButt = new System.Windows.Forms.PictureBox();
            this.roundPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.roundPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ProfileButt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MatchButt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DontMatchButt)).BeginInit();
            this.SuspendLayout();
            // 
            // roundPanel1
            // 
            this.roundPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.roundPanel1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.roundPanel1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.roundPanel1.BorderRadius = 50;
            this.roundPanel1.BorderSize = 0;
            this.roundPanel1.Controls.Add(this.pictureBox4);
            this.roundPanel1.ForeColor = System.Drawing.Color.White;
            this.roundPanel1.Location = new System.Drawing.Point(108, 210);
            this.roundPanel1.Name = "roundPanel1";
            this.roundPanel1.Size = new System.Drawing.Size(408, 373);
            this.roundPanel1.TabIndex = 0;
            this.roundPanel1.TextColor = System.Drawing.Color.White;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(75, 57);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(258, 258);
            this.pictureBox4.TabIndex = 21;
            this.pictureBox4.TabStop = false;
            // 
            // roundPanel2
            // 
            this.roundPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(79)))), ((int)(((byte)(105)))));
            this.roundPanel2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(79)))), ((int)(((byte)(105)))));
            this.roundPanel2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.roundPanel2.BorderRadius = 50;
            this.roundPanel2.BorderSize = 0;
            this.roundPanel2.Controls.Add(this.label3);
            this.roundPanel2.Controls.Add(this.label2);
            this.roundPanel2.Controls.Add(this.label1);
            this.roundPanel2.Controls.Add(this.label5);
            this.roundPanel2.ForeColor = System.Drawing.Color.White;
            this.roundPanel2.Location = new System.Drawing.Point(108, 605);
            this.roundPanel2.Name = "roundPanel2";
            this.roundPanel2.Size = new System.Drawing.Size(408, 129);
            this.roundPanel2.TabIndex = 1;
            this.roundPanel2.TextColor = System.Drawing.Color.White;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Nirmala UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.label3.Location = new System.Drawing.Point(312, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 38);
            this.label3.TabIndex = 30;
            this.label3.Text = "AGE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.label2.Location = new System.Drawing.Point(26, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 28);
            this.label2.TabIndex = 29;
            this.label2.Text = "LOCATION";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.label1.Location = new System.Drawing.Point(26, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 28);
            this.label1.TabIndex = 28;
            this.label1.Text = "LAST NAME";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Nirmala UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.label5.Location = new System.Drawing.Point(26, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(148, 31);
            this.label5.TabIndex = 27;
            this.label5.Text = "FIRST NAME";
            // 
            // ProfileButt
            // 
            this.ProfileButt.BackColor = System.Drawing.Color.Transparent;
            this.ProfileButt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ProfileButt.BackgroundImage")));
            this.ProfileButt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ProfileButt.Location = new System.Drawing.Point(148, 766);
            this.ProfileButt.Name = "ProfileButt";
            this.ProfileButt.Size = new System.Drawing.Size(337, 229);
            this.ProfileButt.TabIndex = 24;
            this.ProfileButt.TabStop = false;
            // 
            // MatchButt
            // 
            this.MatchButt.BackColor = System.Drawing.Color.Transparent;
            this.MatchButt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MatchButt.BackgroundImage")));
            this.MatchButt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.MatchButt.Location = new System.Drawing.Point(404, 751);
            this.MatchButt.Name = "MatchButt";
            this.MatchButt.Size = new System.Drawing.Size(162, 162);
            this.MatchButt.TabIndex = 26;
            this.MatchButt.TabStop = false;
            // 
            // DontMatchButt
            // 
            this.DontMatchButt.BackColor = System.Drawing.Color.Transparent;
            this.DontMatchButt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("DontMatchButt.BackgroundImage")));
            this.DontMatchButt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.DontMatchButt.Location = new System.Drawing.Point(66, 751);
            this.DontMatchButt.Name = "DontMatchButt";
            this.DontMatchButt.Size = new System.Drawing.Size(162, 162);
            this.DontMatchButt.TabIndex = 25;
            this.DontMatchButt.TabStop = false;
            this.DontMatchButt.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // DashboardMatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(621, 1024);
            this.Controls.Add(this.MatchButt);
            this.Controls.Add(this.DontMatchButt);
            this.Controls.Add(this.ProfileButt);
            this.Controls.Add(this.roundPanel2);
            this.Controls.Add(this.roundPanel1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DashboardMatch";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DashboardMatch";
            this.roundPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.roundPanel2.ResumeLayout(false);
            this.roundPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ProfileButt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MatchButt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DontMatchButt)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private RoundPanel roundPanel1;
        private RoundPanel roundPanel2;
        private System.Windows.Forms.PictureBox ProfileButt;
        private System.Windows.Forms.PictureBox MatchButt;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox DontMatchButt;
    }
}