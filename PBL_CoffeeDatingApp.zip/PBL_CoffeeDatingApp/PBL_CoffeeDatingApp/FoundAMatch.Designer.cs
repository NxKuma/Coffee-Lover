﻿
namespace PBL_CoffeeDatingApp
{
    partial class FoundAMatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FoundAMatch));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.circlePicBox1 = new PBL_CoffeeDatingApp.CirclePicBox();
            this.circlePicBox2 = new PBL_CoffeeDatingApp.CirclePicBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.custButton1 = new PBL_CoffeeDatingApp.CustButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.circlePicBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.circlePicBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(190, 443);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(293, 403);
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // circlePicBox1
            // 
            this.circlePicBox1.BackColor = System.Drawing.Color.Transparent;
            this.circlePicBox1.BorderCapStyle = System.Drawing.Drawing2D.DashCap.Round;
            this.circlePicBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(90)))), ((int)(((byte)(81)))));
            this.circlePicBox1.BorderColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.circlePicBox1.BorderLineStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;
            this.circlePicBox1.BorderSize = 8;
            this.circlePicBox1.GradientAngle = 150F;
            this.circlePicBox1.Location = new System.Drawing.Point(98, 359);
            this.circlePicBox1.Name = "circlePicBox1";
            this.circlePicBox1.Size = new System.Drawing.Size(200, 200);
            this.circlePicBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.circlePicBox1.TabIndex = 25;
            this.circlePicBox1.TabStop = false;
            // 
            // circlePicBox2
            // 
            this.circlePicBox2.BackColor = System.Drawing.Color.Transparent;
            this.circlePicBox2.BorderCapStyle = System.Drawing.Drawing2D.DashCap.Round;
            this.circlePicBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(90)))), ((int)(((byte)(81)))));
            this.circlePicBox2.BorderColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.circlePicBox2.BorderLineStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;
            this.circlePicBox2.BorderSize = 8;
            this.circlePicBox2.GradientAngle = 150F;
            this.circlePicBox2.Location = new System.Drawing.Point(350, 359);
            this.circlePicBox2.Name = "circlePicBox2";
            this.circlePicBox2.Size = new System.Drawing.Size(200, 200);
            this.circlePicBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.circlePicBox2.TabIndex = 26;
            this.circlePicBox2.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(98, 82);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(452, 377);
            this.pictureBox2.TabIndex = 28;
            this.pictureBox2.TabStop = false;
            // 
            // custButton1
            // 
            this.custButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.custButton1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.custButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.custButton1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.custButton1.BorderRadius = 80;
            this.custButton1.BorderSize = 0;
            this.custButton1.FlatAppearance.BorderSize = 0;
            this.custButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.custButton1.Font = new System.Drawing.Font("Nirmala UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.custButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custButton1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.custButton1.Location = new System.Drawing.Point(172, 799);
            this.custButton1.Name = "custButton1";
            this.custButton1.Size = new System.Drawing.Size(324, 95);
            this.custButton1.TabIndex = 31;
            this.custButton1.Text = "BREW MORE MATCHES";
            this.custButton1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custButton1.UseVisualStyleBackColor = false;
            // 
            // FoundAMatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(636, 977);
            this.Controls.Add(this.custButton1);
            this.Controls.Add(this.circlePicBox2);
            this.Controls.Add(this.circlePicBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FoundAMatch";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FoundAMatch";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.circlePicBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.circlePicBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private CirclePicBox circlePicBox1;
        private CirclePicBox circlePicBox2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private CustButton custButton1;
    }
}