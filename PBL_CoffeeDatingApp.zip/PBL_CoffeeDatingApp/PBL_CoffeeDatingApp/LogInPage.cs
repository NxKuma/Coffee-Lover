﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PBL_CoffeeDatingApp
{
    public partial class LogInPage : Form
    {
        public LogInPage()
        {
            InitializeComponent();
           
        }


        private void RegistPage_Load(object sender, EventArgs e)
        {

        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void materialCheckbox1_CheckedChanged(object sender, EventArgs e)
        {
            materialCheckbox1.ForeColor = Color.FromArgb(176, 49, 64);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
