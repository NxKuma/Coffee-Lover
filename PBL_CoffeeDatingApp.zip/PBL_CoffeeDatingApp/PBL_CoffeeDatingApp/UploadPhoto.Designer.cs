﻿
namespace PBL_CoffeeDatingApp
{
    partial class Upload_Photo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Upload_Photo));
            this.roundPanel1 = new PBL_CoffeeDatingApp.RoundPanel();
            this.custButton2 = new PBL_CoffeeDatingApp.CustButton();
            this.roundPanel2 = new PBL_CoffeeDatingApp.RoundPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.custButton1 = new PBL_CoffeeDatingApp.CustButton();
            this.circlePicBox1 = new PBL_CoffeeDatingApp.CirclePicBox();
            this.roundPanel1.SuspendLayout();
            this.roundPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.circlePicBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // roundPanel1
            // 
            this.roundPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.roundPanel1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.roundPanel1.BorderColor = System.Drawing.Color.Transparent;
            this.roundPanel1.BorderRadius = 40;
            this.roundPanel1.BorderSize = 0;
            this.roundPanel1.Controls.Add(this.custButton2);
            this.roundPanel1.Controls.Add(this.roundPanel2);
            this.roundPanel1.Controls.Add(this.custButton1);
            this.roundPanel1.ForeColor = System.Drawing.Color.Transparent;
            this.roundPanel1.Location = new System.Drawing.Point(52, 203);
            this.roundPanel1.Name = "roundPanel1";
            this.roundPanel1.Size = new System.Drawing.Size(535, 610);
            this.roundPanel1.TabIndex = 5;
            this.roundPanel1.TextColor = System.Drawing.Color.Transparent;
            // 
            // custButton2
            // 
            this.custButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.custButton2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.custButton2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custButton2.BorderRadius = 50;
            this.custButton2.BorderSize = 5;
            this.custButton2.FlatAppearance.BorderSize = 0;
            this.custButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.custButton2.Font = new System.Drawing.Font("Nirmala UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.custButton2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custButton2.Location = new System.Drawing.Point(131, 520);
            this.custButton2.Name = "custButton2";
            this.custButton2.Size = new System.Drawing.Size(264, 55);
            this.custButton2.TabIndex = 21;
            this.custButton2.Text = "Proceed";
            this.custButton2.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custButton2.UseVisualStyleBackColor = false;
            // 
            // roundPanel2
            // 
            this.roundPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(79)))), ((int)(((byte)(105)))));
            this.roundPanel2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(79)))), ((int)(((byte)(105)))));
            this.roundPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.roundPanel2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.roundPanel2.BorderRadius = 120;
            this.roundPanel2.BorderSize = 0;
            this.roundPanel2.Controls.Add(this.circlePicBox1);
            this.roundPanel2.Controls.Add(this.label7);
            this.roundPanel2.ForeColor = System.Drawing.Color.White;
            this.roundPanel2.Location = new System.Drawing.Point(73, 45);
            this.roundPanel2.Name = "roundPanel2";
            this.roundPanel2.Size = new System.Drawing.Size(389, 367);
            this.roundPanel2.TabIndex = 20;
            this.roundPanel2.TextColor = System.Drawing.Color.White;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.label7.Location = new System.Drawing.Point(96, 312);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(192, 28);
            this.label7.TabIndex = 19;
            this.label7.Text = "Upload Photo Here";
            // 
            // custButton1
            // 
            this.custButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.custButton1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(49)))), ((int)(((byte)(64)))));
            this.custButton1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custButton1.BorderRadius = 50;
            this.custButton1.BorderSize = 5;
            this.custButton1.FlatAppearance.BorderSize = 0;
            this.custButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.custButton1.Font = new System.Drawing.Font("Nirmala UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.custButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custButton1.Location = new System.Drawing.Point(131, 448);
            this.custButton1.Name = "custButton1";
            this.custButton1.Size = new System.Drawing.Size(264, 55);
            this.custButton1.TabIndex = 2;
            this.custButton1.Text = "UPLOAD";
            this.custButton1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.custButton1.UseVisualStyleBackColor = false;
            this.custButton1.Click += new System.EventHandler(this.custButton1_Click);
            // 
            // circlePicBox1
            // 
            this.circlePicBox1.BorderCapStyle = System.Drawing.Drawing2D.DashCap.Round;
            this.circlePicBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(90)))), ((int)(((byte)(81)))));
            this.circlePicBox1.BorderColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(219)))), ((int)(((byte)(198)))));
            this.circlePicBox1.BorderLineStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;
            this.circlePicBox1.BorderSize = 8;
            this.circlePicBox1.GradientAngle = 150F;
            this.circlePicBox1.Location = new System.Drawing.Point(58, 19);
            this.circlePicBox1.Name = "circlePicBox1";
            this.circlePicBox1.Size = new System.Drawing.Size(280, 280);
            this.circlePicBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.circlePicBox1.TabIndex = 20;
            this.circlePicBox1.TabStop = false;
            // 
            // Upload_Photo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(639, 977);
            this.Controls.Add(this.roundPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Upload_Photo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Upload_Photo";
            this.roundPanel1.ResumeLayout(false);
            this.roundPanel2.ResumeLayout(false);
            this.roundPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.circlePicBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private RoundPanel roundPanel1;
        private System.Windows.Forms.Label label7;
        private CustButton custButton1;
        private CustButton custButton2;
        private RoundPanel roundPanel2;
        private CirclePicBox circlePicBox1;
    }
}