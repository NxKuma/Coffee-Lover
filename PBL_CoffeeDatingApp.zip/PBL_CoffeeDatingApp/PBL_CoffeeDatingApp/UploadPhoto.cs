﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PBL_CoffeeDatingApp
{
    public partial class Upload_Photo : Form
    {
        public Upload_Photo()
        {
            InitializeComponent();
        }

        private void custButton1_Click(object sender, EventArgs e)
        {
            String imageLocation = "";
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "jpg files(*.jpg)| *.jpg| PNG files(*.png)| *.png| All Files(*.*)| *.*";

                if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    imageLocation = dialog.FileName;
                    circlePicBox1.ImageLocation = imageLocation;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("An Error Occured", "Eror", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
